import SwiftUI

struct CategoryHome: View {
    @EnvironmentObject var modelData: ModelData

    @State private var showingProfile = false

    var body: some View {
        NavigationSplitView {
            List {
                PageView(pages: modelData.features.map { FeatureCard(landmark: $0) })
                    .listRowInsets(EdgeInsets())

                ForEach(modelData.categories.keys.sorted(), id: \.self) { key in
                    CategoryRow(categoryName: key, items: modelData.categories[key]!)
                }
                .listRowInsets(EdgeInsets())
            }
            .listStyle(.inset)
            .navigationTitle("特色展示")
            .toolbar {
                Button {
                    showingProfile.toggle()
                } label: {
                    Label("User Profile", systemImage: "person.crop.circle")
                }
            }
            // 【修改 2】使用 .environmentObject 传递给 Sheet 中的视图
            .sheet(isPresented: $showingProfile) {
                ProfileHost()
                    .environmentObject(modelData)
            }
        } detail: {
            Text("Select a Landmark")
        }
    }
}

#Preview {
    // 【修改 3】预览时也使用 .environmentObject
    CategoryHome()
        .environmentObject(ModelData())
}
