//import SwiftUI
//
//
//struct LandmarkDetail: View {
//    @Environment(ModelData.self) var modelData
//    var landmark: Landmark
//
//
//    var landmarkIndex: Int {
//        modelData.landmarks.firstIndex(where: { $0.id == landmark.id })!
//    }
//
//
//    var body: some View {
//        @Bindable var modelData = modelData
//
//
//        ScrollView {
//            MapView(coordinate: landmark.locationCoordinate)
//                .frame(height: 300)
//
//
//            CircleImage(image: landmark.image)
//                .offset(y: -130)
//                .padding(.bottom, -130)
//
//
//            VStack(alignment: .leading) {
//                HStack {
//                    Text(landmark.name)
//                        .font(.title)
//                    FavoriteButton(isSet: $modelData.landmarks[landmarkIndex].isFavorite)
//                }
//
//
//                HStack {
//                    Text(landmark.park)
//                    Spacer()
//                    Text(landmark.state)
//                }
//                .font(.subheadline)
//                .foregroundStyle(.secondary)
//
//
//                Divider()
//
//
//                Text("关于 \(landmark.name)")
//                    .font(.title2)
//                Text(landmark.description)
//            }
//            .padding()
//        }
//        .navigationTitle(landmark.name)
//        .navigationBarTitleDisplayMode(.inline)
//    }
//}
//
//#Preview {
//    let modelData = ModelData()
//    return LandmarkDetail(landmark: modelData.landmarks[0])
//        .environment(modelData)
//}


import SwiftUI

struct LandmarkDetail: View {
    @EnvironmentObject var modelData: ModelData
    var landmark: Landmark

    // 【新增 1】控制弹窗显示
    @State private var showCheckIn = false

    // 【新增 2】控制打卡状态 (默认未打卡)
    @State private var hasCheckedIn = false

    var landmarkIndex: Int {
        modelData.landmarks.firstIndex(where: { $0.id == landmark.id })!
    }

    var body: some View {
        ScrollView {
            MapView(coordinate: landmark.locationCoordinate)
                .frame(height: 300)

            CircleImage(image: landmark.image)
                .offset(y: -130)
                .padding(.bottom, -130)

            VStack(alignment: .leading) {
                HStack {
                    Text(landmark.name)
                        .font(.title)
                    FavoriteButton(isSet: Binding(
                        get: { modelData.landmarks[landmarkIndex].isFavorite },
                        set: { newValue in
                            modelData.landmarks[landmarkIndex].isFavorite = newValue
                        }
                    ))
                }

                HStack {
                    Text(landmark.park)
                    Spacer()
                    Text(landmark.state)
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)

                Divider()

                Text("关于 \(landmark.name)")
                    .font(.title2)
                Text(landmark.description)
            }
            .padding()

            Divider()
                .padding(.top, 20)

            // 【新增 3】动态样式的打卡按钮
            Button(action: {
                if !hasCheckedIn {
                    showCheckIn = true
                }
            }) {
                HStack {
                    // 图标根据状态变化
                    Image(systemName: hasCheckedIn ? "checkmark.seal.fill" : "map.pin")
                        .font(.title2)
                        .foregroundColor(.white)

                    // 文字根据状态变化
                    Text(hasCheckedIn ? "已打卡签到" : "打卡签到")
                        .font(.headline)
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
                .padding()
                // 背景色根据状态变化：未打卡为蓝色，已打卡为黄色
                .background(hasCheckedIn ? Color.yellow : Color.blue)
                .cornerRadius(15)
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
            // 【关键】如果已经打卡，则禁用按钮（变灰且无法点击）
            .disabled(hasCheckedIn)
        }
        .navigationTitle(landmark.name)
        .navigationBarTitleDisplayMode(.inline)

        // 【新增 4】Sheet 弹窗与回调
        .sheet(isPresented: $showCheckIn) {
            CheckInView(
                    landmarkID: landmark.id,
                    onSuccess: {
                        // 2. 将原本的回调逻辑放在这里作为参数传递
                        // 当 CheckInView 内部调用 onSuccess() 时，这里的代码才会执行
                        hasCheckedIn = true
                        print("用户已成功打卡地标：\(landmark.name)")
                    }
                )
        }
    }
}

#Preview {
    let modelData = ModelData()
    return LandmarkDetail(landmark: modelData.landmarks[0])
        .environmentObject(ModelData())
}
