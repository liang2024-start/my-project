import SwiftUI

struct CheckInView: View {
    let landmarkID: Int
    // 【新增】接收现有的记录，如果是 nil 则表示新建模式
    var existingRecord: CheckInRecord? = nil
    var onSuccess: (() -> Void)? = nil
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var modelData: ModelData

    // 状态变量
    @State private var selectedDate = Date()
    @State private var selectedMood: Mood = .happy
    @State private var rating: Int = 5
    @State private var logText: String = ""

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("基本信息")) {
                    DatePicker("打卡日期", selection: $selectedDate, displayedComponents: [.date])

                    Picker("此刻心情", selection: $selectedMood) {
                        ForEach(Mood.allCases) { mood in
                            HStack {
                                Text(mood.rawValue).font(.title2)
                                Text(mood.description) // 假设你的 Mood 枚举里有 description 属性，或者直接用 rawValue
                            }.tag(mood)
                        }
                    }
                }

                Section(header: Text("游玩评价")) {
                    HStack {
                        Text("推荐指数")
                        Spacer()
                        StarRatingView(rating: $rating)
                    }
                }

                Section(header: Text("游玩日志")) {
                    TextEditor(text: $logText)
                        .frame(minHeight: 100)
                        .overlay(
                            Group {
                                if logText.isEmpty {
                                    Text("写下你的游玩感受...")
                                        .foregroundColor(.gray)
                                        .padding(.leading, 4)
                                        .padding(.top, 8)
                                }
                            }, alignment: .topLeading
                        )
                }
            }
            .navigationTitle(existingRecord == nil ? "打卡签到" : "编辑足迹") // 根据模式改变标题
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        saveCheckIn()
                    }
                    .bold()
                }
            }
            // 【关键修改 3】视图加载时，如果有现有记录，则填充数据
            .onAppear {
                if let record = existingRecord {
                    self.selectedDate = record.date
                    self.selectedMood = record.mood
                    self.rating = record.rating
                    self.logText = record.note
                }
            }
        }
    }

    func saveCheckIn() {
        if let record = existingRecord {
            // --- 编辑模式 ---
            // 找到对应的记录索引
            if let index = modelData.checkIns.firstIndex(where: { $0.id == record.id }) {
                // 直接修改数组中该位置的数据
                // 注意：因为第一步已经把属性改成了 var，这里就不会报错了
                modelData.checkIns[index].date = selectedDate
                modelData.checkIns[index].mood = selectedMood
                modelData.checkIns[index].rating = rating
                modelData.checkIns[index].note = logText
            }
        } else {
            // --- 新建模式 ---
            let newRecord = CheckInRecord(
                landmarkID: landmarkID,
                date: selectedDate,
                mood: selectedMood,
                rating: rating,
                note: logText
            )
            modelData.checkIns.append(newRecord)
        }

        if let callback = onSuccess {
                    callback()
                }
        
        dismiss()
    }
}

struct StarRatingView: View {
    @Binding var rating: Int
    var maxStars: Int = 5

    var body: some View {
        HStack(spacing: 4) {
            ForEach(1...maxStars, id: \.self) { index in
                Image(systemName: index <= rating ? "star.fill" : "star")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 24, height: 24)
                    .foregroundColor(index <= rating ? .yellow : .gray.opacity(0.3))
                    .onTapGesture {
                        withAnimation(.spring(response: 0.2)) {
                            rating = index
                        }
                    }
            }
        }
    }
}

#Preview {
    CheckInView(landmarkID: 1)
        .environmentObject(ModelData())
}
