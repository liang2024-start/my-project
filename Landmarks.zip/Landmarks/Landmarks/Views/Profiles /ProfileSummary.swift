import SwiftUI

struct ProfileSummary: View {
    var profile: Profile
    @EnvironmentObject var modelData: ModelData

    // 【关键修改 1】添加回调闭包属性
    // 这是一个可选的函数类型，接收一个 CheckInRecord 参数，没有返回值
    var onCheckInTap: ((CheckInRecord) -> Void)? = nil

    // 【新增】计算属性：获取最近的打卡记录，按时间倒序排列
    var recentCheckIns: [CheckInRecord] {
        modelData.checkIns.sorted(by: { $0.date > $1.date })
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text(profile.username)
                    .bold()
                    .font(.title)

                Text("通知: \(profile.prefersNotifications ? "开": "关" )")
                Text("季节性照片: \(profile.seasonalPhoto.rawValue)")
                Text("目标日期: ") + Text(profile.goalDate, style: .date)

                Divider()

                // --- 原有徽章部分 ---
                VStack(alignment: .leading) {
                    Text("已完成徽章")
                        .font(.headline)

                    ScrollView(.horizontal) {
                        HStack {
                            HikeBadge(name: "首次徒步路行")
                            HikeBadge(name: "地球日")
                                .hueRotation(Angle(degrees: 90))
                            HikeBadge(name: "第十次远行")
                                .grayscale(0.5)
                                .hueRotation(Angle(degrees: 45))
                        }
                        .padding(.bottom)
                    }
                }

                Divider()

                // --- 原有徒步部分 ---
                VStack(alignment: .leading) {
                    Text("近期徒步")
                        .font(.headline)

                    HikeView(hike: modelData.hikes[0])
                }

                Divider()

                // --- 【修改 2】打卡记录部分 ---
                VStack(alignment: .leading) {
                    Text("我的足迹")
                        .font(.headline)

                    if recentCheckIns.isEmpty {
                        Text("暂无打卡记录，快去探索吧！")
                            .foregroundStyle(.secondary)
                            .padding(.top, 10)
                    } else {
                        List(recentCheckIns) { record in
                            // 【关键修改 3】将每一行包装成 Button
                            // 点击时调用父视图传来的 onCheckInTap 闭包
                            Button(action: {
                                self.onCheckInTap?(record)
                            }) {
                                CheckInRow(record: record, landmarks: modelData.landmarks)
                            }
                        }
                        // 设置列表样式，使其看起来不像传统的表格，更像内嵌内容
                        .listStyle(.plain)
                        // 动态高度：如果记录少于3条就自适应，多于3条限制高度滚动
                        .frame(height: CGFloat(min(recentCheckIns.count, 3)) * 60)
                    }
                }
            }
            .padding()
        }
    }
}

// 【辅助视图】打卡记录的行样式 (保持不变)
struct CheckInRow: View {
    let record: CheckInRecord
    let landmarks: [Landmark]

    // 计算属性：根据 ID 查找对应的地标名字
    private var landmarkName: String {
        if let landmark = landmarks.first(where: { $0.id == record.landmarkID }) {
            return landmark.name
        }
        return "未知地点"
    }

    var body: some View {
        HStack {
            // 左侧：地标名字 + 日期
            VStack(alignment: .leading) {
                Text(landmarkName)
                    .font(.body)
                    .fontWeight(.medium)

                Text(record.date, style: .date)
                    .font(.caption)
                    .foregroundStyle(.gray)
            }

            Spacer()

            // 右侧：心情图标 + 评分
            HStack(spacing: 8) {
                Text(record.mood.rawValue) // 显示 Emoji
                    .font(.title3)

                Text("\(record.rating)星")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    // 显式创建 ModelData 实例用于预览
    let modelData = ModelData()

    return ProfileSummary(profile: modelData.profile)
        // 预览时传入一个空的闭包，防止报错
        .environmentObject(modelData)
}
