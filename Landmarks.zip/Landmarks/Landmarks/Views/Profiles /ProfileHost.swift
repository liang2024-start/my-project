import SwiftUI

struct ProfileHost: View {
    @Environment(\.editMode) var editMode
    @State private var draftProfile = Profile.default
    @EnvironmentObject var modelData: ModelData

    // 【新增】状态变量
    @State private var showCheckInView = false
    @State private var selectedRecord: CheckInRecord? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                if editMode?.wrappedValue == .active {
                    Button("Cancel", role: .cancel) {
                        draftProfile = modelData.profile
                        editMode?.animation().wrappedValue = .inactive
                    }
                }
                Spacer()
                EditButton()
            }

            if editMode?.wrappedValue == .inactive {
                ProfileSummary(
                    profile: modelData.profile,
                    onCheckInTap: { record in
                        // 点击列表项时触发
                        self.selectedRecord = record
                        self.showCheckInView = true
                    }
                )
            } else {
                ProfileEditor(profile: $draftProfile)
                    .onAppear {
                        draftProfile = modelData.profile
                    }
                    .onDisappear {
                        modelData.profile = draftProfile
                    }
            }
        }
        .padding()
        // 【关键修改】Sheet 必须直接挂载在 VStack 之后
        .sheet(isPresented: $showCheckInView) {
            if let record = selectedRecord {
                // 编辑模式：传入具体的记录 ID 和数据
                CheckInView(landmarkID: record.landmarkID, existingRecord: record)
            } else {
                // 新建模式：默认传入一个 ID (例如 1)，实际项目中可根据业务调整
                CheckInView(landmarkID: 1)
            }
            // 注意：这里不需要 .environmentObject(modelData)
            // 因为 CheckInView 会自动从环境中获取同一个 modelData 实例
        }
    }
}

#Preview {
    ProfileHost()
        .environmentObject(ModelData())
}
