//
//  CircleImage.swift
//  Landmarks
//
//  Created by 403-47 on 2026/5/25.
//

import SwiftUI

struct CircleImage: View {
    var image:Image
    
    var body: some View {
        //Image("turtlerock")
        image
            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
            .overlay {
                Circle().stroke(.white,lineWidth: 4)
            }
            .shadow(radius: 7)
    }
}

#Preview {
    CircleImage(image: Image("雅鲁藏布江"))
}
