import Foundation
import SwiftUI

// 1. 定义心情枚举 (建议直接放在这里，方便管理)
enum Mood: String, Codable, CaseIterable, Identifiable {
    case happy = "😄"
    case neutral = "😐"
    case sad = "😢"
    case excited = "🤩"
    case tired = "😫"

    var id: String { self.rawValue }

    // 获取对应的中文描述（可选，用于显示）
    var description: String {
        switch self {
        case .happy: return "开心"
        case .neutral: return "平静"
        case .sad: return "难过"
        case .excited: return "兴奋"
        case .tired: return "疲惫"
        }
    }
}

// 2. 定义打卡记录模型
struct CheckInRecord: Identifiable, Codable {
    let id: UUID
    var landmarkID: Int      // 关联的地标 ID
    var date: Date           // 打卡时间
    var mood: Mood           // 心情
    var rating: Int          // 评分 (1-5)
    var note: String         // 日志内容
    
    // 自定义初始化方法，方便创建新记录
    init(id: UUID = UUID(), landmarkID: Int, date: Date = Date(), mood: Mood = .happy, rating: Int = 5, note: String = "") {
        self.id = id
        self.landmarkID = landmarkID
        self.date = date
        self.mood = mood
        self.rating = rating
        self.note = note
    }
}

